import React  from 'react';
import Todolist from './components/Todolist';
import './App.css'

function App() {
   return (
    <Todolist/>
  )
}

export default App;
