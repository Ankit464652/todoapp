import React, { useState } from 'react'
import Listcom from './Listcom'

export default function Todolist() {
    const [item , setItem] = useState('');
    const [newitem, setNewItem]= useState ([ ]);

    const itemEvent = (event) => {
        setItem(event.target.value);
    
    }

    const listItem = () => {
        setNewItem((prevValue) => {
         
            return[...prevValue, item]
        });
    setItem("");
    };

    const deletItem =(key)=>{
      let newListTodo = [...item];
      newListTodo.splice(key,1)
      setNewItem([...newListTodo])
    }

  return (
    <>
    <div className="main-container">
      <div className="center-container">
        <h1 className='mt-3'>TODO LIST</h1>
        <br />
        <input type="text" value={item} placeholder='Add an Item' required onChange= {itemEvent} />
        <button type="button" onClick={listItem} className="btn btn-primary  m-2">Add</button>
        
        <br />

        <ol >
          
          
         { newitem.map((val , index) => {
            return <Listcom key= {index} index={index} text={val} deletItem={deletItem}/>
          }
          ) }
        </ol>
      </div>

    </div>
    </>
  );
};
