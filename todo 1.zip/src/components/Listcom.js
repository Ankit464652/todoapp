import React from 'react';


const Listcom = (props)=> {
    return (
   <>
    <span className='icons'>
    <li> {props.text} </li> 
    <i className="fa-solid fa-trash-can icon-delete"
    onClick={e=>{props.deletItem(props.index)}}></i>
       
    </span>
 

   </>
  );
}
 export default Listcom;